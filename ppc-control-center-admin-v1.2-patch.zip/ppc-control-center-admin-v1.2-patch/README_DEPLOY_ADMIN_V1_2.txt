PPC Control Center - Admin v1.2

Zakres:
1. Admin -> Klienci pokazuje nazwe konta/klienta z raportu CENTRAL zamiast powtarzac ID.
2. W Podglad jako Specjalista widac opcje "Dodaj konto reklamowe". W podgladzie zapis jest zablokowany; po prawdziwym logowaniu Specjalisty zapis dziala.
3. Admin moze przepinac konta miedzy aktywnymi pracownikami z poziomu Klienci -> Przypisz.
   - Meta Ads: zmiana Uzytkownik + Email, BM pozostaje bez zmian.
   - Google Ads: zmiana Uzytkownik + Email + MCK_ID na aktywne MCK nowego opiekuna.
   - jesli nowy opiekun ma kilka MCK, Admin wybiera wlasciwe MCK.
   - jesli nie ma aktywnego MCK, transfer Google jest blokowany.

Wdrozenie na obecne Admin v1.1:
PODMIEN:
- index.html
- auth.js
- accounts.js
- admin.js
- api/accounts/self-service.js
- api/admin/overview.js
- api/_lib/access.js

DODAJ:
- api/admin/accounts.js

Nie ma nowych Environment Variables.
Nie trzeba zmieniac Google Cloud, OIDC ani uprawnien arkuszy.

Smoke test po deploy:
A. Admin -> Klienci
- nazwa klienta jest pogrubiona
- ID jest mniejszym tekstem pod nazwa
- jest kolumna Akcje -> Przypisz

B. Admin -> Podglad jako Adrian
- Narzedzia -> Dodaj konto reklamowe jest widoczne
- modal mozna otworzyc
- przycisk zapisu jest zablokowany w trybie podgladu

C. Adrian zalogowany swoim kontem
- Dodaj konto reklamowe jest widoczne
- Google pokazuje jego MCK
- Meta pokazuje aktywne BM
- zapis jest aktywny

D. Przepinanie
- Google: wybierz konto -> Przypisz -> pracownik -> MCK -> Przypisz konto
- Meta: wybierz konto -> Przypisz -> pracownik -> Przypisz konto
- po zapisie tabela Admina pokazuje nowego opiekuna
- uprawnienia dashboardu odswiezaja sie po ponownym pobraniu danych / odswiezeniu strony
