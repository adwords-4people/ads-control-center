const { getAuthContext, isAdmin, clearMappingsCache } = require('../_lib/access');
const {
  IDS,
  fetchSheetByName,
  isActive,
  normalizeEmail,
  normalizeGoogleId,
  normalizeMetaId,
  setSheetRowValues,
} = require('../_lib/sheets');
const { loadUsers } = require('../_lib/users');

const GOOGLE_SHEET = 'Konta - Google Ads';
const META_SHEET = 'Konta - Meta Ads';
const MCK_SHEET = 'MCK - Google Ads';

function clean(value) { return String(value == null ? '' : value).trim(); }
function json(res, status, payload) {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  return res.end(JSON.stringify(payload));
}
function readBody(req) {
  if (req.body && typeof req.body === 'object') return req.body;
  if (typeof req.body === 'string' && req.body.trim()) return JSON.parse(req.body);
  return {};
}
function rowValues(headers, row, updates) {
  return headers.map(header => Object.prototype.hasOwnProperty.call(updates, header) ? updates[header] : clean(row[header]));
}

module.exports = async function handler(req, res) {
  try {
    const context = await getAuthContext(req);
    if (!context) return json(res, 401, { ok: false, error: 'unauthenticated' });
    if (!isAdmin(context.actualUser)) return json(res, 403, { ok: false, error: 'forbidden' });
    if (context.previewing) return json(res, 409, { ok: false, error: 'preview_mode', message: 'Wyłącz Podgląd jako użytkownik przed zmianą przypisania konta.' });
    if (req.method !== 'POST') return json(res, 405, { ok: false, error: 'method_not_allowed' });

    const body = readBody(req);
    const platform = clean(body.platform);
    const targetEmail = normalizeEmail(body.targetEmail);
    const requestedSourceId = clean(body.sourceId);
    if (!['Google Ads', 'Meta Ads'].includes(platform)) {
      return json(res, 400, { ok: false, error: 'invalid_platform', message: 'Nieprawidłowa platforma.' });
    }

    const users = await loadUsers(req);
    const target = users.find(user => user.active && normalizeEmail(user.email) === targetEmail);
    if (!target) {
      return json(res, 400, { ok: false, error: 'invalid_user', message: 'Wybierz aktywnego pracownika.' });
    }

    if (platform === 'Google Ads') {
      const accountId = normalizeGoogleId(body.accountId);
      if (!accountId) return json(res, 400, { ok: false, error: 'invalid_account_id', message: 'Brak ID konta Google Ads.' });
      const [sheet, mckSheet] = await Promise.all([
        fetchSheetByName(IDS.config, GOOGLE_SHEET, req),
        fetchSheetByName(IDS.config, MCK_SHEET, req),
      ]);
      const index = sheet.rows.findIndex(row => normalizeGoogleId(row['ID Konta']) === accountId);
      if (index < 0) return json(res, 404, { ok: false, error: 'not_found', message: 'Nie znaleziono konta Google Ads w konfiguracji.' });

      const allowedMcks = mckSheet.rows.filter(row =>
        isActive(row['Aktywne']) && normalizeEmail(row['Email']) === targetEmail && clean(row['MCK_ID'])
      );
      if (!allowedMcks.length) {
        return json(res, 400, { ok: false, error: 'no_mck', message: 'Wybrany pracownik nie ma aktywnego MCK. Najpierw przypisz mu MCK w konfiguracji.' });
      }
      let mck = allowedMcks.find(row => clean(row['MCK_ID']) === requestedSourceId);
      if (!mck && allowedMcks.length === 1) mck = allowedMcks[0];
      if (!mck) {
        return json(res, 400, { ok: false, error: 'mck_required', message: 'Wybrany pracownik ma więcej niż jedno MCK. Wybierz właściwe MCK.' });
      }

      const row = sheet.rows[index];
      const updates = {
        'MCK_ID': clean(mck['MCK_ID']),
        'Użytkownik': clean(target.name),
        'Email': targetEmail,
      };
      await setSheetRowValues(IDS.config, GOOGLE_SHEET, index + 2, rowValues(sheet.headers, row, updates), req);
      clearMappingsCache();
      return json(res, 200, {
        ok: true,
        platform,
        accountId: clean(row['ID Konta']),
        target: { email: targetEmail, name: target.name },
        sourceId: clean(mck['MCK_ID']),
      });
    }

    const accountId = normalizeMetaId(body.accountId);
    if (!accountId) return json(res, 400, { ok: false, error: 'invalid_account_id', message: 'Brak ID konta Meta Ads.' });
    const sheet = await fetchSheetByName(IDS.config, META_SHEET, req);
    const index = sheet.rows.findIndex(row => normalizeMetaId(row['ID Konta']) === accountId);
    if (index < 0) return json(res, 404, { ok: false, error: 'not_found', message: 'Nie znaleziono konta Meta Ads w konfiguracji.' });
    const row = sheet.rows[index];
    const updates = {
      'Użytkownik': clean(target.name),
      'Email': targetEmail,
    };
    await setSheetRowValues(IDS.config, META_SHEET, index + 2, rowValues(sheet.headers, row, updates), req);
    clearMappingsCache();
    return json(res, 200, {
      ok: true,
      platform,
      accountId: clean(row['ID Konta']),
      target: { email: targetEmail, name: target.name },
      sourceId: clean(row['BM_ID']),
    });
  } catch (error) {
    console.error('[Admin account assignment]', error);
    return json(res, 500, { ok: false, error: 'account_assignment_failed', message: error.message });
  }
};
